package pt.uc.sd;

public record Message(String content) {

}
