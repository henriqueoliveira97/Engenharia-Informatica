package search;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.concurrent.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

public class User {

    public static void main(String[] args) {
        try {
            ConfigLoader configLoader = new ConfigLoader();
            String ip = configLoader.getProperty("server.ip");
            int port = configLoader.getIntProperty("server.port");
            String name = configLoader.getProperty("server.name");
            AtomicReference<Index> index = new AtomicReference<>((Index) LocateRegistry.getRegistry(ip,port).lookup(name));
            User user = new User();
            Scanner sc = new Scanner(System.in);
            List<String[]> lista = index.get().top10();
            System.out.println("####################################################################### " );
            System.out.println("###                             GOOGOL                              ### " );
            System.out.println("### Add urls for indexing: Start with \"http\"                        ### " );
            System.out.println("### Search keywords: start with anything else                       ### ");
            System.out.println("### Type \"0\" to view system stats                                   ### ");
            System.out.println("### Type \"1\" to view active barrels                                 ### ");
            System.out.println("### Type \"2\" to view the average response time                      ### ");
            System.out.println("### Type \"3\" to view the list of links that link to a certain link  ### ");
            System.out.println("#######################################################################");

            new Thread(() -> {
                while (true) {
                    try {
                        index.get().getMessage();
                        Thread.sleep(5000);
                    } catch (RemoteException e) {
                        System.err.println("Perdemos a conexão com o Index. Tentando reconectar...");
                        index.set(user.reconnectToIndex(ip,port,name));
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }).start();

            while (sc.hasNextLine()) {
                System.out.print("Input: ");
                int start = 0;
                String nome = sc.nextLine().trim();

                if (nome.equalsIgnoreCase("0")) {
                    CopyOnWriteArrayList<String[]> top10 = index.get().top10();
                    if(!lista.equals(top10)) {
                        System.out.println("\n==== Top 10 Pesquisas Mais Comuns ====");
                        int i = 1;
                        for (String[] entry : top10) {
                            System.out.println(i++ + "º: \"" + entry[0] + "\" - " + entry[1]);
                        }
                        System.out.println("=======================================\n");
                        lista=top10;
                    }else{
                        System.out.println("Não foram feitas alterações no top10");
                    }

                } else if (nome.equalsIgnoreCase("1")) {
                    Map<String, Integer>resultado = index.get().listarBarrels();
                    if (resultado == null || resultado.isEmpty()) {
                        System.out.println("Nenhum barrel ativo...");
                    } else {
                        for (Map.Entry<String, Integer> entry : resultado.entrySet()) {
                            if (entry.getValue() >= 0) {
                                System.out.println(entry.getKey() + " - Tamanho do índice: " + entry.getValue());
                            } else {
                                System.out.println(entry.getKey() + " inacessível.");
                            }
                        }
                    }
                }else if (nome.equalsIgnoreCase("2")) {
                    Map<String, Double>resultado = index.get().GetAvgtime();
                    if (resultado == null || resultado.isEmpty()) {
                        System.out.println("Nenhum barrel disponível para calcular tempos de resposta.");
                    } else {
                        for (Map.Entry<String, Double> entry : resultado.entrySet()) {
                            try {
                                if (entry.getValue() >= 0) {
                                    System.out.println(entry.getKey() + " - Tempo médio de resposta: " + entry.getValue());
                                } else {
                                    System.out.println(entry.getKey() + " inacessível.");
                                }
                            } catch (Exception e) {
                                System.out.println(entry.getKey() + " inacessível.");
                            }
                        }
                    }
                }else if (nome.equalsIgnoreCase("3")) {
                    System.out.println("Introduza o link:");
                    String url = sc.nextLine();
                    ArrayList<String> referencias = index.get().getLinkeLinks(url);
                    if (!referencias.isEmpty()) {
                        for (String link : referencias) {
                            System.out.println(link);
                        }
                    } else {
                        System.out.println("Nenhuma página contém ligação para esse link.");
                    }
                } else {
                    String[] divisao = nome.split(":");
                    if (divisao[0].equals("https") || divisao[0].equals("http")) {
                        System.out.println("-> Server: " + nome);
                        index.get().putNew(nome);
                    } else {
                        String[] palavras = nome.split(" ");
                        Set<InfoPage> resultadosIntersecionados = null;
                        for (String palavra : palavras) {
                            System.out.println("Palavra: " + palavra);
                            List<InfoPage> resultadosPalavra = index.get().searchWord(palavra,index.get(),start);
                            index.get().getPesquisas(palavra);

                            if (resultadosPalavra == null || resultadosPalavra.isEmpty()) {
                                resultadosIntersecionados = Collections.emptySet();
                                break;
                            }

                            Set<InfoPage> resultadosSet = new HashSet<>(resultadosPalavra);

                            if (resultadosIntersecionados == null) {
                                resultadosIntersecionados = resultadosSet;
                            } else {
                                resultadosIntersecionados.retainAll(resultadosSet); // interseção
                            }
                        }

                        if (resultadosIntersecionados == null || resultadosIntersecionados.isEmpty()) {
                            System.out.println("Nenhum resultado encontrado para todas as palavras.");
                        } else {
                            List<InfoPage> ordenados = sortResults(index.get(), new ArrayList<>(resultadosIntersecionados));

                            int pageSize = 10;
                            int total = ordenados.size();
                            Scanner scanner = new Scanner(System.in);
                            System.out.println("-> Server: ");
                            for (int i = 0; i < total; i++) {
                                InfoPage page = ordenados.get(i);
                                System.out.println("Título: " + page.getTitulo());
                                System.out.println("Citação: " + page.getCitacao());
                                System.out.println("URLs: " + page.getUrl());
                                System.out.println("--------------------------------------------------");

                                if ((i + 1) % pageSize == 0 && i + 1 < total) {
                                    System.out.println("Pressiona Enter para ver mais resultados... ");
                                    scanner.nextLine();
                                    start++;
                                }

                                if ((i + 1) == total) {
                                    System.out.println("Não existem mais links...\n");
                                }
                            }
                        }
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static List<InfoPage> sortResults(Index index, List<InfoPage> results) {
        if (results == null || results.isEmpty()) {
            return results;
        }
        Collections.sort(results, (page1, page2) -> {
            try {
                int importancia1 = index.importanciaLink(page1.getUrl());
                int importancia2 = index.importanciaLink(page2.getUrl());
                return Integer.compare(importancia2, importancia1);
            } catch (RemoteException e) {
                e.printStackTrace();
                return 0;
            }
        });

        return results;
    }

    private Index reconnectToIndex(String ip, int port, String name) {
        while (true) {
            try {
                System.out.println("Tentando reconectar ao Index...");
                Index index = (Index) LocateRegistry.getRegistry(ip,port).lookup(name);
                System.out.println("Reconectado ao Index com sucesso!");
                return index;
            } catch (Exception e) {
                System.err.println("Falha ao reconectar. Tentando novamente em 5 segundos...");
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}