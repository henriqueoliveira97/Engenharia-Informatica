package search;

import java.rmi.*;
import java.util.*;

public interface RobotCallBack extends Remote {
    //public String WorkerStatsCallback() throws java.rmi.RemoteException;

}