cd src/main/java/
javac -d ../../../target/ -cp ../../../target/lib/jsoup-1.18.3.jar search/*.java pt/uc/sd/MessagingCallBack.java
cd ../../../
