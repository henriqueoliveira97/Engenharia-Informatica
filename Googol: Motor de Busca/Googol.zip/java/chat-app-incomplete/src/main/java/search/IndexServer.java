package search;

import pt.uc.sd.MessagingCallBack;

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.concurrent.*;
import java.io.*;
import java.util.*;

public class IndexServer extends UnicastRemoteObject implements Index {
    private  Stack<String> urlsToIndex ;
    private ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> indexMap;
    private CopyOnWriteArrayList<String[]> top10 = new CopyOnWriteArrayList<>();
    private Set<String> urlsVisitados;
    private List<RobotCallBack> robots = new ArrayList<>();
    private Queue<String> urlsProblematicos;
    private List<BarrelInterface> barrels = new ArrayList<>();
    private ConcurrentHashMap<String, ArrayList<String>> backLinks = new ConcurrentHashMap<>();

    private ConcurrentHashMap<String, ArrayList<String>> linkedLinks;

    private ConcurrentHashMap<String, Integer> pesquisas = new ConcurrentHashMap<>();
    private List<MessagingCallBack> callbacks = new ArrayList<>();
    private int initialBarrels = 2; //meter no property files
    private int indexNextBarrel = 0;


    public IndexServer() throws RemoteException {
        super();
        //This structure has a number of problems. The first is that it is fixed size. Can you enumerate the others?
        urlsToIndex = new Stack<>();
        File urlsToIndexFile = new File("urlsToIndex.txt");
        if(urlsToIndexFile.exists()){
            try {
                urlsToIndex = getUrlsFromFile();
            }catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        else {
            urlsToIndex = new Stack<>();
        }

        File Indexfile = new File("index.dat");
        if(Indexfile.exists()){
            indexMap = getIndexfile();
        }
        else {
            indexMap = new ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>>();
        }
        File linkedLinksfile = new File("linkedLinks.dat");
        if(linkedLinksfile.exists()){
            linkedLinks = getLinkedlinksfile();
        }
        else {
            linkedLinks = new ConcurrentHashMap<>();
        }
        File pesquisasfile = new File("pesquisas.dat");
        if(pesquisasfile.exists()){
            pesquisas = getpesquisasfile();
        }
        else {
            pesquisas =  new ConcurrentHashMap<String, Integer>();
        }
        urlsVisitados= new HashSet<>();
        urlsProblematicos= new ConcurrentLinkedQueue<>();
        startPeriodicSaveThread();
        addShutdownHook();
    }

    public static void main(String args[]) {
        try {
            IndexServer server = new IndexServer();
            ConfigLoader configLoader = new ConfigLoader();
            String ip = configLoader.getProperty("server.ip");
            int port = configLoader.getIntProperty("server.port");
            String name = configLoader.getProperty("server.name");
            Registry registry = LocateRegistry.createRegistry(port);
            registry.rebind(name, server);
            server.initialBarrels= configLoader.getIntProperty("server.initialBarrels");
            System.out.println("Server ready. Waiting for input...");
            //server.putNew("https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal");
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
    //private long counter = 0, timestamp = 0, finalf, timeI=System.currentTimeMillis();;

    public synchronized String takeNext() throws RemoteException {
        //counter++;
        //finalf = System.currentTimeMillis()-timeI;
        //timestamp += finalf;
        //if(counter>=10){
        //    System.out.println("Average time: "+timestamp/10+" ms");
        //    long mem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        //    System.out.println("Memory usage: "+ mem);
        //    viewstats();
        //    counter=0;
        //    timestamp=0;
        //}
        while (urlsToIndex.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        return urlsToIndex.pop();
    }


    public synchronized void putNew(String url) throws java.rmi.RemoteException {
        if(urlsVisitados.contains(url) || urlsProblematicos.contains(url)){
            return;
        }
        urlsVisitados.add(url);
        urlsToIndex.push(url);
        notifyAll();
        notifyCallbacks();
    }

    public void addToIndex(String word, InfoPage url) throws java.rmi.RemoteException {
        if(barrels.isEmpty()){
            GetAck();
        }
        for(BarrelInterface barrel : barrels) {
            try {
                GetAck();
                barrel.addToIndex(word, url);
            } catch (Exception e) {
                System.out.println("Falha no envio para o barrel");
            }
        }
        notifyCallbacks();
    }


    public List<InfoPage> searchWord(String word,Index index,int start) throws java.rmi.RemoteException {
        List<InfoPage> allUrls = new ArrayList<>();
        if(barrels.isEmpty() || StopWord(word)){
            return allUrls;
        }

        try{
            BarrelInterface barrel = barrels.get(indexNextBarrel);
            indexNextBarrel= (indexNextBarrel +1)% barrels.size();

            long tempInicial = System.currentTimeMillis();
            allUrls = barrel.searchWord(word, tempInicial,index,start);
        } catch ( Exception e) {
            try{
                BarrelInterface barrel2 = barrels.get(indexNextBarrel);
                indexNextBarrel= (indexNextBarrel +1)% barrels.size();

                long tempInicial2 = System.currentTimeMillis();
                allUrls = barrel2.searchWord(word, tempInicial2,index,start);
            } catch ( Exception ex) {
                System.out.println("Nenhum barrels consegui buscar...");
                e.printStackTrace();
            }
        }
        notifyCallbacks();
        return allUrls;
    }

    //public void viewstats() throws java.rmi.RemoteException{
    //    String stat;
    //    for(RobotCallBack robot: robots){
    //        try{
    //            stat = robot.WorkerStatsCallback();
    //            System.out.println("robot: "+ stat);
    //        } catch (RemoteException e) {
    //            System.out.println("Robô inacessível: " + e.getMessage());
    //            robots.remove(robot);
    //        }
//
    //    }
    //}
    public void getRobot(RobotCallBack Robot) throws java.rmi.RemoteException {
        robots.add(Robot);
    }

    public void getBarrel(BarrelInterface Barrel) throws java.rmi.RemoteException{
        barrels.add(Barrel);
    }

    //public void printIndex(ConcurrentHashMap<String, ArrayList<String>> indexMap){ //teste para ver o addShutdownHook
    //    for(Map.Entry<String, ArrayList<String>> entry : indexMap.entrySet()){
    //        System.out.println("Chave: " + entry.getKey());
    //    }
    //}

    public void adicionarProblematicas(String url) throws java.rmi.RemoteException{
        System.out.println("Adicionei problemático: "+ url);
        urlsProblematicos.offer(url);
    }

    public void adicionarBackLinks(String url, ArrayList<String> links){
        backLinks.put(url, links);
        for(String link: links){
            addLinkedlink(link, url);
        }
    }
    public int importanciaLink(String url){
        if(!linkedLinks.containsKey(url))return 0;
        List<String> linksLinking = linkedLinks.get(url);
        return linksLinking.size();
    }

    public void addLinkedlink(String url, String keyLinked) {
        if (linkedLinks.containsKey(url)) {
            linkedLinks.get(url).add(keyLinked);
        } else {
            ArrayList<String> list = new ArrayList<>();
            list.add(keyLinked);
            linkedLinks.put(url, list);
        }
    }

    public void getPesquisas(String pesquisa){
        if(pesquisas.containsKey(pesquisa)){
            pesquisas.put(pesquisa, pesquisas.get(pesquisa)+1);
        }else{
            pesquisas.put(pesquisa,1);
        }
    }

    public CopyOnWriteArrayList<String[]> top10() {
        List<Map.Entry<String, Integer>> lista = new ArrayList<>(pesquisas.entrySet());
        lista.sort((a, b) -> b.getValue().compareTo(a.getValue()));


        top10.clear();
        int limite = Math.min(10, lista.size());
        for (int i = 0; i < limite; i++) {
            Map.Entry<String, Integer> entry = lista.get(i);
            top10.add(new String[]{entry.getKey(), String.valueOf(entry.getValue())});
        }

        return top10;
    }


    public Map<String, Integer> listarBarrels() {
        Map<String, Integer> resultado = new ConcurrentHashMap<>();
        int i = 1;
        for (BarrelInterface barrel : barrels) {
            try {
                int tamanho = barrel.getIndexSize();
                resultado.put("Barrel " + i, tamanho);
            } catch (RemoteException e) {
                resultado.put("Barrel " + i, -1);
            }
            i++;
        }
        return resultado;
    }

    public Map<String, Double> GetAvgtime() throws java.rmi.RemoteException{
        Map<String, Double> resultado = new ConcurrentHashMap<>();
        int i = 1;
        for(BarrelInterface barrel : barrels){
            try {
                double tempMed = barrel.getTempMed();
                resultado.put("Barrel " + i, tempMed);
            }catch (Exception e){
                resultado.put("Barrel inacessível " + i, -1.);
            }
            i++;
        }
        return resultado;
    }


    public void saveIndex(ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> indexMap) throws java.rmi.RemoteException  {
        if (indexMap != null) {
            File file = new File("index.dat");
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                oos.writeObject(indexMap);
            } catch (IOException e) {
                throw new RemoteException("Erro ao meter dados no ficheiro.", e);
            }
        }
    }

    public void saveLinkedlinks(ConcurrentHashMap<String, ArrayList<String>> linkedLinks) throws java.rmi.RemoteException  {
        if (linkedLinks != null) {
            File file = new File("linkedLinks.dat");
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                oos.writeObject(linkedLinks);
            } catch (IOException e) {
                throw new RemoteException("Erro ao meter dados no ficheiro.", e);
            }
        }
    }

    public void savepesquisas(ConcurrentHashMap<String, Integer> pesquisas) throws java.rmi.RemoteException  {
        if (top10 != null) {
            File file = new File("pesquisas.dat");
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                oos.writeObject(pesquisas);
            } catch (IOException e) {
                throw new RemoteException("Erro ao meter dados no ficheiro.", e);
            }
        }
    }
    public ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> getIndexfile() throws java.rmi.RemoteException{
        try {
            File file = new File("index.dat");
            ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file));
            return (ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>>) oos.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new RemoteException("Erro ao meter dados no ficheiro.", e);
        }
    }
    public ConcurrentHashMap<String, ArrayList<String>> getLinkedlinksfile() throws java.rmi.RemoteException{
        try {
            File file = new File("linkedLinks.dat");
            ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file));
            return (ConcurrentHashMap<String, ArrayList<String>>) oos.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new RemoteException("Erro ao meter dados no ficheiro.", e);
        }
    }

    public ConcurrentHashMap<String, Integer> getpesquisasfile() throws java.rmi.RemoteException{
        try {
            File file = new File("pesquisas.dat");
            ObjectInputStream oos = new ObjectInputStream(new FileInputStream(file));
            return (ConcurrentHashMap<String, Integer>) oos.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new RemoteException("Erro ao meter dados no ficheiro.", e);
        }
    }
    public Stack<String> getUrlsFromFile()  throws IOException {
        Stack<String> urlsToIndexFile = new Stack<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("urlsToIndex.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Ignora linhas em branco ou com apenas espaços
                if (line.trim().isEmpty()) {
                    continue;
                }
                urlsToIndexFile.push(line.trim());
            }
        }
        return urlsToIndexFile;
    }

    public ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> getIndexMap() throws java.rmi.RemoteException{
        return this.indexMap;
    }

    public void setIndexMap(ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> indexMap) throws java.rmi.RemoteException{
        this.indexMap = indexMap;
    }

    public void GetAck() throws RemoteException {
        int received = 0;

        while (received < initialBarrels) {
            received = 0;
            List<BarrelInterface> copy = new ArrayList<>(barrels);
            for (BarrelInterface barrel : copy) {
                boolean acknowledged = false;
                for (int tries = 0; tries < 3; tries++) {
                    try {
                        barrel.getMessage();
                        acknowledged = true;
                        break;
                    } catch (Exception e) {
                        try {
                            Thread.sleep(1000); // Espera 1 segundo antes de tentar de novo
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                        }
                    }
                }
                if (acknowledged) {
                    received++;
                } else {
                    System.out.println("Removendo barrel após falha em 3 tentativas.");
                    barrels.remove(barrel);
                }
            }
        }
    }

    public void addShutdownHook() throws java.rmi.RemoteException{
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                saveIndex(indexMap); // Salva o índice antes de fechar
                saveLinkedlinks(linkedLinks); // Salva o linkedLinks antes de fechar
            } catch (RemoteException e) {
                System.err.println("Erro ao guardar dados durante o encerramento: " + e.getMessage());
            }
        }
        ));
    }
    public ArrayList<String> getLinkeLinks(String url){
        if(linkedLinks.containsKey(url)){
            return linkedLinks.get(url);
        }else{
            return new ArrayList<>();
        }
    }

    public void verifyIfOther(BarrelInterface barrelNew, Index index) throws java.rmi.RemoteException{
        int indexNew = barrelNew.getIndexSize();
        for(BarrelInterface barrel : barrels) {
            if(barrel.getIndexSize() > indexNew){
                indexMap = barrel.getIndexMap();
                barrelNew.setIndexMap(index);
                break;
            }
        }
    }

    public boolean StopWord(String word){
        if(indexMap.containsKey(word)){
            double tamanho = indexMap.get(word).size();
            if(urlsVisitados.isEmpty()) return false;
            if((tamanho / urlsVisitados.size()) >= 0.9){
                return true;
            }
        }
        return false;
    }

    public int getMessage()  throws java.rmi.RemoteException{
        return 1;
    }

    private void startPeriodicSaveThread() {
        Thread saveThread = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(20000);
                    ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> indexTosave;
                    if(!barrels.isEmpty()){
                        BarrelInterface barrel = barrels.get(0);
                        indexTosave = barrel.getIndexMap();
                    }
                    else {
                        indexTosave = indexMap;
                    }
                    saveIndex(indexTosave);
                    saveLinkedlinks(linkedLinks);
                    top10();
                    savepesquisas(pesquisas);
                    System.out.println("Backup periódico realizado com sucesso.");
                } catch (InterruptedException | RemoteException e) {
                    System.err.println("Erro ao realizar backup periódico: " + e.getMessage());
                }
            }
        });
        saveThread.start();
    }

    @Override
    public void registerCallback(MessagingCallBack callback) throws RemoteException {
        callbacks.add(callback);
    }
    private void notifyCallbacks() {
        for (MessagingCallBack cb : callbacks) {
            try {
                cb.enviarEstatisticasParaClientes();
            } catch (RemoteException e) {
                System.out.println("Erro ao chamar callback.");
            }
        }
    }



}