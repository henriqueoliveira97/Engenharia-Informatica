package pt.uc.sd;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface MessagingCallBack extends Remote {
    void enviarEstatisticasParaClientes() throws RemoteException;
}
