
function clearMessages() {
    document.getElementById("messages").innerHTML = "";
}

let currentPageIndex = 0; // Variável global de página atual

function showMessage(message) {
    const messagesTable = document.getElementById("messages");
    messagesTable.innerHTML = "";
    const row = messagesTable.insertRow();
    const cell = row.insertCell(0);
    cell.innerHTML = message.replace(/\n/g, "<p>");

    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = message;
    const resultadoDivs = tempDiv.querySelectorAll("div[style*='border:1px solid']");

    const nextBtn = document.getElementById("nextPage");
    const prevBtn = document.getElementById("prevPage");

    if (nextBtn) {
        nextBtn.style.display = resultadoDivs.length >= 10 ? "flex" : "none";
    }
    if (prevBtn) {
        const isNotFirstPage = message.includes("Página Anterior") || currentPageIndex > 0;
        prevBtn.style.display = isNotFirstPage ? "flex" : "none";
    }

}



function sendMessage() {
    const messageInput = document.getElementById("message").value.trim();
    fetch("/api/message?page_index=" + currentPageIndex, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ content: messageInput })
    })
    .then(response => response.json())
    .then(data => {
        showMessage(data.content);
    })
    .catch(error => console.error("Erro ao enviar mensagem:", error));
}


function linkedLinks() {
    const url = document.getElementById("message").value.trim();
    fetch("/api/linkedLinks?url=" + encodeURIComponent(url))
        .then(res => res.text())
        .then(data => showMessage("Linked Links:\n" + data));
}

function loadNextPage() {
    currentPageIndex++;
    sendMessage();
}

function loadPrevPage() {
    if (currentPageIndex > 0) {
        currentPageIndex--;
        sendMessage();
    }
}



function fetchTopHackerNews() {
    const palavra = document.getElementById("message").value.trim();
    fetch("/api/hackernews?palavra=" + encodeURIComponent(palavra))
        .then(res => res.text())
        .then(data => showMessage("Hacker News:\n" + data));
}

window.addEventListener('load', function () {

    document.getElementById("send").addEventListener('click', function (e) {
        e.preventDefault();
        clearMessages();
        sendMessage();
    });

    // Para paginação
    document.getElementById("nextPage").addEventListener("click", function () {
        currentPageIndex++;
        loadNextPage();
    });
    document.getElementById("prevPage").addEventListener("click", function () {
        if (currentPageIndex > 0) currentPageIndex--;
        loadPrevPage();
    });

    document.getElementById("fetchTop").addEventListener('click', function (e) {
        e.preventDefault();
        clearMessages();
        fetchTopHackerNews();
    });

    document.getElementById("LinkedLinks").addEventListener('click', function (e) {
        e.preventDefault();
        clearMessages();
        linkedLinks();
    });
});

