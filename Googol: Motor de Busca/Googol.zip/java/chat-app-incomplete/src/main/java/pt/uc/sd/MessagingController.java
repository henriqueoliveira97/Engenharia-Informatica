package pt.uc.sd;

import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.HtmlUtils;
import org.springframework.stereotype.Controller;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.client.RestTemplate;
import search.Index;
import search.InfoPage;
import search.ConfigLoader;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.json.JSONArray;
import org.json.JSONObject;

@RestController
@Controller
public class MessagingController extends UnicastRemoteObject implements MessagingCallBack {
    private final SimpMessagingTemplate simpMessagingTemplate;
    private RestTemplate restTemplate;

    private Index rmiServidor;

    public MessagingController(SimpMessagingTemplate simpMessagingTemplate) throws RemoteException {
        super();
        this.restTemplate = new RestTemplate();
        this.simpMessagingTemplate= simpMessagingTemplate;
        try {
            ConfigLoader config = new ConfigLoader();
            String ip = config.getProperty("server.ip");
            int port = config.getIntProperty("server.port");
            String name = config.getProperty("server.name");

            this.rmiServidor = (Index) LocateRegistry.getRegistry(ip, port).lookup(name);
            System.out.println("Conectado ao servidor RMI com sucesso.");
            rmiServidor.registerCallback(this);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Erro ao conectar ao servidor RMI: " + e.getMessage());
        }
    }

    @PostMapping("/api/message")
    public Message onMessage(@RequestBody Message message,@RequestParam(defaultValue = "0") int page_index) {
        System.out.println("Message received: " + message);
        String content = message.content();
        StringBuilder resposta = new StringBuilder();
        if(page_index == 0) {
            String analiseIA = gerarAnalise(content);
            resposta.append("<div><strong>Análise IA da palavra/pedido:</strong><br>")
                    .append(analiseIA)
                    .append("</div><hr>");
        }
        try {
            if (content.toLowerCase().startsWith("http")) {
                rmiServidor.putNew(content);
                resposta.append("<div><strong>URL enviada para indexação:</strong> ").append(content).append("</div><hr>");
                return new Message(resposta.toString());
            }

            rmiServidor.getPesquisas(content);

            List<InfoPage> resultados = rmiServidor.searchWord(content,rmiServidor,page_index);
            if (resultados == null || resultados.isEmpty()) {
                resposta.append(" Nenhum resultado encontrado para: \n").append(content).append("\n");
            } else {
                resultados.sort((p1, p2) -> {
                    try {
                        return Integer.compare(
                                rmiServidor.importanciaLink(p2.getUrl()),
                                rmiServidor.importanciaLink(p1.getUrl())
                        );
                    } catch (RemoteException e) {
                        return 0;
                    }
                });
                int resultados_size = resultados.size();


                resposta.append(" Resultados encontrados:\n");
                for (InfoPage page : resultados) {
                    resposta.append(String.format("""
                        <tr>
                            <td>
                                <div style='border:1px solid #ccc; padding:6px; margin-bottom:6px;'>
                                    <strong>Título:</strong> %s<br>
                                    <strong>URL:</strong> <a href='%s' target='_blank'>%s</a><br>
                                    <strong>Descrição:</strong> %s
                                </div>
                            </td>
                        </tr>
                    """, page.getTitulo(), page.getUrl(), page.getUrl(), page.getCitacao()));

                }
            }


        } catch (RemoteException e) {
            e.printStackTrace();
            resposta.append(" Erro ao acessar o servidor remoto para a palavra: \"").append(content).append("\"");
        }

        return new Message(resposta.toString());
    }

    @MessageMapping("/listar-barrels")
    @SendTo("/topic/barrels")
    public String listarBarrels() {
        try {
            Map<String, Integer> resultado = rmiServidor.listarBarrels();
            Map<String, Double> resultado2 = rmiServidor.GetAvgtime();
            if (resultado == null || resultado.isEmpty()) {
                return "Nenhum barrel ativo...";
            } else {
                StringBuilder sb = new StringBuilder("Barrels Ativos:\n");
                for (Map.Entry<String, Integer> entry : resultado.entrySet()) {
                    String barrel = entry.getKey();
                    int tamanho = entry.getValue();

                    if (tamanho >= 0) {
                        double avgTime = -1.0;
                        if (resultado2 != null && resultado2.containsKey(barrel)) {
                            avgTime = resultado2.get(barrel);
                        }

                        sb.append(barrel)
                                .append(" - Tamanho do índice: ").append(tamanho);

                        if (avgTime >= 0) {
                            sb.append(" | Tempo médio de resposta: ").append(String.format("%.2f ms", avgTime));
                        } else {
                            sb.append(" | Tempo médio de resposta: N/A");
                        }

                        sb.append("\n");
                    } else {
                        sb.append(barrel).append(" inacessível.\n");
                    }
                }
                return sb.toString();
            }
        } catch (RemoteException e) {
            return "Erro ao contactar RMI: " + e.getMessage();
        }
    }

    @MessageMapping("/top10")
    @SendTo("/topic/top10")
    public String top10() {
        try {
            List<String[]> top10 = rmiServidor.top10();
            if (top10 == null || top10.isEmpty()) {
                return "Ainda não há pesquisas suficientes para gerar o top 10.";
            }

            StringBuilder sb = new StringBuilder("\n==== Top 10 Pesquisas Mais Comuns ====\n");
            int i = 1;
            for (String[] entry : top10) {
                sb.append(i++).append("º: ").append(entry[0]).append(" - ").append(entry[1]).append("\n");
            }
            sb.append("=======================================\n");
            return sb.toString();
        } catch (RemoteException e) {
            return "Erro ao contactar RMI: " + e.getMessage();
        }
    }

    @GetMapping("/api/linkedLinks")
    public String linkedLinks(@RequestParam String url) {
        try {
            List<String> linkedLinks = rmiServidor.getLinkeLinks(url);
            if (linkedLinks == null || linkedLinks.isEmpty()) {
                return "Nenhuma página contém ligação para o link fornecido: " + url;
            }

            StringBuilder sb = new StringBuilder("\n==== Links que apontam para: ").append(url).append(" ====\n");
            for (String link : linkedLinks) {
                sb.append(link).append("\n");
            }
            sb.append("=======================================\n");

            return sb.toString();
        } catch (RemoteException e) {
            return "Erro ao contactar RMI: " + e.getMessage();
        }
    }

    @GetMapping("/api/hackernews")
    public String fetchTopItems(@RequestParam String palavra) {
        String baseUrl = "https://hacker-news.firebaseio.com/v0/";
        try {
            rmiServidor.getPesquisas(palavra);
            if(palavra.isEmpty() || palavra.equals("")){
                return "Ensira algo para procurar no Hacker news.";
            }
            // Obter os top stories
            String[] topStoryIds = restTemplate.getForObject(baseUrl + "topstories.json", String[].class);
            if (topStoryIds == null) return "Não foi possível obter histórias.";

            List<String> matchingTitles = new ArrayList<>();
            List<String> linksToIndex = new ArrayList<>();
            int count = 0;
            int i = 0;
            for (String id : topStoryIds) {
                if (count >= 10) break;
                if (i >= 100) break;
                try {
                    String itemUrl = baseUrl + "item/" + id + ".json";
                    JSONObject itemJson = new JSONObject(restTemplate.getForObject(itemUrl, String.class));
                    String title = itemJson.optString("title", "[Sem título]");
                    String realUrl = itemJson.optString("url", null);

                    if (title.toLowerCase().contains(palavra.toLowerCase())) {
                        matchingTitles.add(title);
                        if (realUrl != null && !realUrl.isEmpty()) {
                            linksToIndex.add(realUrl);
                        }
                        count++;
                    }

                } catch (Exception e) {
                    matchingTitles.add("[Erro ao carregar item]");
                    count++;
                }
                i++;
            }
                for (String link : linksToIndex) {
                    rmiServidor.putNew(link);
                }

            if (matchingTitles.isEmpty()) {
                return "Nenhum título encontrado contendo: " + palavra;
            }

            StringBuilder response = new StringBuilder("Top Títulos contendo \"" + palavra + "\":\n");
            response.append(String.join(".\n", matchingTitles));

            if (!linksToIndex.isEmpty()) {
                response.append("\n\n").append(linksToIndex.size())
                        .append(" link(s) foram adicionados à fila de indexação.");
            }

            return response.toString();

        } catch (Exception e) {
            return "Falha ao contactar API externa: " + e.getMessage();
        }
    }


    private String gerarAnalise(String prompt) {
        try {
            prompt = "Forneça uma descrição objetiva e informativa sobre o termo abaixo, como se fosse exibida nos primeiros resultados de uma pesquisa na internet sem meter as palavras em negrito: " + prompt;
            // Montar o corpo da requisição
            JSONObject textPart = new JSONObject().put("text", prompt);
            JSONArray partsArray = new JSONArray().put(textPart);
            JSONObject content = new JSONObject().put("parts", partsArray);
            JSONArray contentsArray = new JSONArray().put(content);
            JSONObject body = new JSONObject().put("contents", contentsArray);

            // Fazer a requisição
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> request = new HttpEntity<>(body.toString(), headers);

            ResponseEntity<String> response = restTemplate.postForEntity(GEMINI_ENDPOINT, request, String.class);

            // Processar a resposta
            if (response.getStatusCode().is2xxSuccessful()) {
                JSONObject json = new JSONObject(response.getBody());
                JSONArray candidates = json.optJSONArray("candidates");

                if (candidates != null && !candidates.isEmpty()) {
                    JSONObject firstCandidate = candidates.getJSONObject(0);
                    JSONObject contentJson = firstCandidate.optJSONObject("content");

                    if (contentJson != null) {
                        JSONArray parts = contentJson.optJSONArray("parts");
                        if (parts != null && !parts.isEmpty()) {
                            return parts.getJSONObject(0).optString("text", "Texto não encontrado.");
                        }
                    }
                }
                return "Nenhuma resposta válida na estrutura JSON.";
            } else {
                return "Erro HTTP: " + response.getStatusCode();
            }

        } catch (Exception e) {
            return "Erro ao contactar a API Gemini: " + e.getMessage();
        }
    }

    private static final String API_KEY = "AIzaSyBItMNVfFMgwhWgU5ZkFlKKYwkmMa7SdPg";
    private static final String GEMINI_ENDPOINT =
            "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=" + API_KEY;

    public void enviarEstatisticasParaClientes() {
        try {
            // Buscar dados dos barrels
            Map<String, Integer> barrels = rmiServidor.listarBarrels();
            Map<String, Double> temposMedios = rmiServidor.GetAvgtime();

            StringBuilder sb = new StringBuilder("Estatísticas dos Barrels:\n");

            for (String nomeBarrel : barrels.keySet()) {
                int tamanho = barrels.get(nomeBarrel);
                double tempoMedio = temposMedios.getOrDefault(nomeBarrel, -1.0);

                sb.append(nomeBarrel)
                        .append(" -> Tamanho: ").append(tamanho)
                        .append(", Tempo médio: ").append(tempoMedio >= 0 ? tempoMedio + " ms" : "N/A")
                        .append("\n");
            }

            // Enviar estatísticas gerais dos barrels
            simpMessagingTemplate.convertAndSend("/topic/barrels", sb.toString());

            // Obter e enviar Top 10
            List<String[]> top10 = rmiServidor.top10(); // ou Map<String, Integer>

            StringBuilder top10Msg = new StringBuilder("Top 10:\n");
            int pos = 1;
            for (String[] entrada : top10) {
                top10Msg.append(pos++)
                        .append(". ")
                        .append(String.join(" - ", entrada))
                        .append("\n");
            }

            simpMessagingTemplate.convertAndSend("/topic/top10", top10Msg.toString());

        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }


}