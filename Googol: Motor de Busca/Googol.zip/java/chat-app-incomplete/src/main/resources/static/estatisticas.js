var stompClient = null;
function setConnected(connected) {
    if (connected) {
        document.getElementById("conversation").style.display = "block";
    } else {
        document.getElementById("conversation").style.display = "none";
        document.getElementById("connect").removeAttribute("disabled");
        document.getElementById("connect").classList.remove("disabled");
        document.getElementById("disconnect").setAttribute("disabled", 'true');
        document.getElementById("disconnect").classList.add("disabled");
    }
    document.getElementById("messages").innerHTML = "";
}

function clearMessages() {
    document.getElementById("messages").innerHTML = "";
}

let barrelsData = "";
let top10Data = "";

function updateStats() {
    const messagesTable = document.getElementById("messages");
    messagesTable.innerHTML = "";

    const row = messagesTable.insertRow();
    const cell = row.insertCell(0);
    cell.innerHTML = barrelsData.replace(/\n/g, "<p>") + "<hr>" + top10Data.replace(/\n/g, "<p>");
}

function connect() {
    const socket = new SockJS("/my-websocket");
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        setConnected(true);
        console.log("Connected: " + frame);

        stompClient.subscribe("/topic/barrels", function (message) {
            barrelsData = message.body;
            updateStats();
        });

        stompClient.subscribe("/topic/top10", function (message) {
            top10Data = message.body;
            updateStats();
        });

        stompClient.send("/app/top10", {}, {});
        stompClient.send("/app/listar-barrels", {}, {});
    });
}

function showStats(message) {
    clearMessages();
    const messagesTable = document.getElementById("messages");
    const row = messagesTable.insertRow();
    const cell = row.insertCell(0);
    cell.innerHTML = message.replace(/\n/g, "<p>");
}

window.addEventListener('load', function () {
     connect();
});
