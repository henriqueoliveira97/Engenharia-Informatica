package search;

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.concurrent.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;


public class Barrel extends UnicastRemoteObject implements BarrelInterface {
    private ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> indexMap = new ConcurrentHashMap<>();
    private List<Long> tempMed = new ArrayList<Long>();
    public Barrel() throws RemoteException {
        super();
    }
    public static void main(String args[]) {
        try {
            ConfigLoader configLoader = new ConfigLoader();
            String ip = configLoader.getProperty("server.ip");
            int port = configLoader.getIntProperty("server.port");
            String name = configLoader.getProperty("server.name");
            AtomicReference<Index> index = new AtomicReference<>((Index) LocateRegistry.getRegistry(ip,port).lookup(name));
            Barrel barrel = new Barrel();
            index.get().getBarrel(barrel);
            barrel.setIndexMap(index.get());
            index.get().verifyIfOther(barrel, index.get());
            barrel.addShutdownHook(index.get());
            System.out.println("Barrel ready. Waiting...");
            new Thread(() -> {
                while (true) {
                    try {
                        Thread.sleep(10000);
                        index.get().getMessage();
                    } catch (RemoteException e) {
                        System.err.println("Perdeu a conexão com o Index. Tentando reconectar...");
                        index.set(reconnectToIndex(ip,port,name));
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
            }).start();
            //server.putNew("https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized void addToIndex(String word, InfoPage info) throws java.rmi.RemoteException {
        CopyOnWriteArrayList<InfoPage> urls = indexMap.get(word);
        if (urls == null) {
            urls = new CopyOnWriteArrayList<InfoPage>();
        }

        if (!urls.contains(info)) {
            urls.add(info);
        }

        indexMap.put(word, urls);
    }



    public List<InfoPage> searchWord(String word, long time,Index index,int page_index) throws java.rmi.RemoteException {
        System.out.println("Este barrel fez a pesquisa.");
        List<InfoPage> urls = indexMap.get(word);
        if(urls == null){
            return new ArrayList<InfoPage>();
        }
        sortResults(index,urls);
        long timeF = System.currentTimeMillis();
        long temp = timeF - time;
        int start = page_index * 10;
        int end = Math.min(start + 10, urls.size());
        if (start >= urls.size()) {
            return new ArrayList<>();
        }
        tempMed.add(temp);
        return (urls != null) ? new ArrayList<>(urls.subList(start, end)) : new ArrayList<InfoPage>();
    }


    public int getIndexSize() throws java.rmi.RemoteException {
        return indexMap.size();
    }

    public ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> getIndexMap() throws java.rmi.RemoteException {
        return indexMap;
    }

    public void setIndexMap(Index index) throws java.rmi.RemoteException {
        indexMap = index.getIndexMap();
    }

    public double getTempMed() throws java.rmi.RemoteException{
        long soma = 0;
        for (Long num : tempMed) {
            soma += num;
        }
        double mediaMs = soma / (double) tempMed.size();
        double mediaDecimos = mediaMs / 100.0;

        return mediaDecimos;
    }

    public int getMessage()  throws java.rmi.RemoteException{
        return 1;
    }

    private static Index reconnectToIndex(String ip, int port, String name) {
        while (true) {
            try {
                System.out.println("Tentando reconectar ao Index...");
                Index index = (Index) LocateRegistry.getRegistry(ip,port).lookup(name);
                Barrel barrel = new Barrel();
                index.getBarrel(barrel);
                barrel.setIndexMap(index);
                index.verifyIfOther(barrel,index);
                barrel.addShutdownHook(index);
                System.out.println("Reconectado ao Index com sucesso!");
                return index;
            } catch (Exception e) {
                System.err.println("Falha ao reconectar. Tentando novamente em 5 segundos...");
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
    public void addShutdownHook(Index index) throws java.rmi.RemoteException{
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                if(index.getIndexMap().size() < indexMap.size()) {
                    index.setIndexMap(indexMap);
                }
                //passar index para o server
            } catch (RemoteException e) {
                System.err.println("Erro ao guardar dados durante o encerramento: " + e.getMessage());
            }
        }
        ));
    }


    private static List<InfoPage> sortResults(Index index, List<InfoPage> results) {
        if (results == null || results.isEmpty()) {
            return results;
        }
        Collections.sort(results, (page1, page2) -> {
            try {
                int importancia1 = index.importanciaLink(page1.getUrl());
                int importancia2 = index.importanciaLink(page2.getUrl());
                return Integer.compare(importancia2, importancia1);
            } catch (RemoteException e) {
                e.printStackTrace();
                return 0;
            }
        });

        return results;
    }
}
