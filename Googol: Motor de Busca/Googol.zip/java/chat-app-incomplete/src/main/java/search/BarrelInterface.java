package search;
import java.rmi.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public interface BarrelInterface extends Remote{
    public void addToIndex(String word, InfoPage info) throws java.rmi.RemoteException;
    public List<InfoPage> searchWord(String word, long time,Index index,int page_index) throws java.rmi.RemoteException;
    public int getIndexSize() throws java.rmi.RemoteException;

    public double getTempMed() throws java.rmi.RemoteException;
    public void setIndexMap(Index index) throws java.rmi.RemoteException;
    public int getMessage()  throws java.rmi.RemoteException;
    public void addShutdownHook(Index index) throws java.rmi.RemoteException;
    public ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> getIndexMap() throws java.rmi.RemoteException;
}