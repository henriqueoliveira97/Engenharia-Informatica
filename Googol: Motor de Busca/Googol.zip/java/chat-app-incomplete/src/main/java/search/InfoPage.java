package search;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class InfoPage implements Serializable {
    private String url;
    private String titulo;
    private String citacao;

    public InfoPage(String url, String titulo, String citacao) {
        this.url = url;
        this.titulo = titulo;
        this.citacao = citacao;
    }


    public String getUrl() {
        return url;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getCitacao() {
        return citacao;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        InfoPage other = (InfoPage) obj;
        return this.url.equals(other.url); // Igual se tiver a mesma URL
    }

    @Override
    public String toString() {
        return "Título: " + titulo + "\nURL: " + url + "\nCitação: " + citacao;
    }
}