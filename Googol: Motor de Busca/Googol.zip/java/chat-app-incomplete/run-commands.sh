cd chat-app-incomplete\target
java -cp "./lib/jsoup-1.18.3.jar;." search.IndexServer
java -cp "./lib/jsoup-1.18.3.jar;." search.Robot
java -cp "./lib/jsoup-1.18.3.jar;." search.User
java -cp "./lib/jsoup-1.18.3.jar;." search.Barrel
