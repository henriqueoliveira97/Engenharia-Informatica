package search;

import java.rmi.RemoteException;
import java.rmi.registry.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;

public class Robot extends UnicastRemoteObject implements RobotCallBack {
    //private int counter = 1;
    //public String WorkerStatsCallback() throws java.rmi.RemoteException {
    //    return "Numero de urls indexados corretamente: "+ counter;
    //}
    public Robot() throws RemoteException {
        super();
    }
    public static void main(String[] args) {
        Index index = null;
        try {
            ConfigLoader configLoader = new ConfigLoader();
            String ip = configLoader.getProperty("server.ip");
            int port = configLoader.getIntProperty("server.port");
            String name = configLoader.getProperty("server.name");
            index = (Index) LocateRegistry.getRegistry(ip,port).lookup(name);
            Robot robot = new Robot();
            index.getRobot(robot);
            System.out.println("Robot ready");

            while (true) {
                try {
                    String url = index.takeNext();
                    System.out.println(url);
                    Document doc;
                    try {
                        doc = Jsoup.connect(url).get();
                        String titulo = doc.title();
                        String paragrafo = doc.select("p").first().text();
                        String frase = paragrafo.split("\\.")[0] + ".";

                        InfoPage info = new InfoPage(url, titulo, frase);
                        StringTokenizer words = new StringTokenizer(doc.text());
                        while (words.hasMoreElements()) {
                            index.addToIndex(words.nextToken().toLowerCase(), info);
                        }

                        Elements links = doc.select("a[href]");
                        ArrayList<String> outLinks = new ArrayList<>();
                        for (Element link : links) {
                            index.putNew(link.attr("abs:href"));
                            outLinks.add(link.attr("abs:href"));
                        }
                        index.adicionarBackLinks(url, outLinks);
                    } catch (Exception e) {
                        index.adicionarProblematicas(url);
                    }
                } catch (RemoteException e) {
                    System.err.println("Conexão perdida com Index! Tentando reconectar...");
                    index = reconnectToIndex(ip,port,name);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static Index reconnectToIndex(String ip, int port, String name) {
        while (true) {
            try {
                System.out.println("Tentando reconectar ao Index...");
                Index index = (Index) LocateRegistry.getRegistry(ip,port).lookup(name);
                index.getRobot(new Robot());
                System.out.println("Reconectado ao Index com sucesso!");
                return index;
            } catch (Exception e) {
                System.err.println("Falha ao reconectar. Tentando novamente em 5 segundos...");
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }


    //https://pt.wikipedia.org/wiki/Wikip%C3%A9dia:P%C3%A1gina_principal
}