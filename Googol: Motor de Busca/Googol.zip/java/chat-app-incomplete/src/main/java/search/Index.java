package search;

import pt.uc.sd.MessagingCallBack;

import java.rmi.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public interface Index extends Remote {
    public String takeNext() throws RemoteException;
    public void putNew(String url) throws java.rmi.RemoteException;
    public void addToIndex(String word, InfoPage url) throws java.rmi.RemoteException;
    public List<InfoPage> searchWord(String word,Index index,int start) throws java.rmi.RemoteException;
    public void getRobot(RobotCallBack Robot) throws java.rmi.RemoteException;
    public void getBarrel(BarrelInterface Barrel) throws java.rmi.RemoteException;

    public void adicionarProblematicas(String url) throws java.rmi.RemoteException;
    public void adicionarBackLinks(String url, ArrayList<String> links) throws java.rmi.RemoteException;
    public int importanciaLink(String url) throws java.rmi.RemoteException;
    public void getPesquisas(String pesquisa) throws java.rmi.RemoteException;
    public CopyOnWriteArrayList<String[]> top10() throws java.rmi.RemoteException;
    public Map<String, Integer> listarBarrels() throws java.rmi.RemoteException;
    public Map<String, Double> GetAvgtime() throws java.rmi.RemoteException;
    public ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> getIndexMap() throws java.rmi.RemoteException;
    public void addShutdownHook() throws java.rmi.RemoteException;
    public void setIndexMap(ConcurrentHashMap<String, CopyOnWriteArrayList<InfoPage>> indexMap) throws java.rmi.RemoteException;
    public void GetAck() throws java.rmi.RemoteException;
    public ArrayList<String> getLinkeLinks(String url) throws java.rmi.RemoteException;
    public void verifyIfOther(BarrelInterface barrelNew, Index index)throws java.rmi.RemoteException;
    public int getMessage()  throws java.rmi.RemoteException;
    void registerCallback(MessagingCallBack callback) throws RemoteException;
}